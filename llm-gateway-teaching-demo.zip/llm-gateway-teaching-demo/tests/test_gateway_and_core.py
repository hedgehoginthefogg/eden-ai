import os, tempfile, importlib, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["GATEWAY_DB"] = tempfile.mktemp(suffix=".db")
os.environ.pop("ANTHROPIC_API_KEY", None)
from fastapi.testclient import TestClient
import gateway.app as g
from lib import core

c = TestClient(g.app)
U = {"X-Demo-User": "tester"}
PARA = ("WHO depends heavily on voluntary contributions. Earmarked funds make up 80% of its budget, so donors decide which "
        "programmes it runs. This limits its ability to respond to priorities set by its member states, because money follows "
        "donor choices rather than collective decisions taken in the Assembly.")

def run(tid, vars, headers=U):
    return c.post(f"/v1/run/{tid}", json={"variables": vars}, headers=headers)

def test_unknown_template_refused():
    assert run("free-chat", {"PROMPT": "hi"}).status_code == 404

def test_extra_variable_refused():
    assert run("paragraph-feedback", {"PARAGRAPH": PARA, "STATED_CLAIM": "WHO lacks independence", "X": "y"}).status_code == 422

def test_too_long_refused():
    assert run("paragraph-feedback", {"PARAGRAPH": "w " * 400, "STATED_CLAIM": "WHO lacks independence"}).status_code == 422

def test_teacher_template_needs_token():
    assert run("cohort-insights", {"STATS": "", "RECORDS": "[]"}).status_code == 403
    assert run("cohort-insights", {"STATS": "", "RECORDS": "[]"}, {"X-Teacher-Token": g.TEACHER_TOKEN}).status_code == 200

def test_limit_and_logging():
    h = {"X-Demo-User": "limit-user"}
    codes = [run("paragraph-feedback", {"PARAGRAPH": PARA, "STATED_CLAIM": "WHO lacks independence"}, h).status_code for _ in range(4)]
    assert codes == [200, 200, 200, 429]
    calls = c.get("/admin/calls", headers={"X-Teacher-Token": g.TEACHER_TOKEN}).json()
    assert sum(1 for x in calls if x["user"] == "limit-user") == 3
    refusals = c.get("/admin/refusals", headers={"X-Teacher-Token": g.TEACHER_TOKEN}).json()
    assert any(r["user"] == "limit-user" for r in refusals)

def test_admin_needs_token():
    assert c.get("/admin/results").status_code == 403

def test_results_round_trip():
    assert c.post("/v1/results", json={"exercise": "ex1", "item": "gates", "record": {"stage": "done", "s1": 4}}, headers=U).status_code == 200
    mine = c.get("/v1/my-results", headers=U).json()
    assert mine[-1]["record"]["s1"] == 4

def test_model_answers_score_full_marks():
    spec = core.load_spec()
    for p in spec["ex2"]:
        marks = {ch["id"]: ch["key"] for ch in p["chunks"] if ch["key"] != "none"}
        assert core.score_ex2(p, marks, p["noClaim"])["all_right"]

def test_clean_result_drops_invented_quotes():
    text = "WHO is underfunded. Its budget is small."
    r = core.clean_result({"spans": [{"part": "claim", "quote": "WHO is underfunded."}, {"part": "evidence", "quote": "not in text"}],
                           "missing": [], "claim_match": {"level": "matches", "comment": ""}, "pointers": ["a"], "overall": {"type": "mixed", "comment": ""}}, text)
    assert len(r["spans"]) == 1 and r["dropped"] == 1 and "evidence" in r["missing"]

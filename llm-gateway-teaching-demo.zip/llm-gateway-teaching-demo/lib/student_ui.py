"""The student activity: three exercises built from ipywidgets.

Exercises 1 and 2 are marked here against fixed answers in activity_spec.json.
Exercise 3 asks the gateway to run its registered "paragraph-feedback"
template. Every check and every submission is saved to the gateway.
"""
import copy
import html
import time

import ipywidgets as W
from IPython.display import display

from . import client
from .core import CONF, LABEL, LOWER, MATCH, PARTS, TYPE, clean_result, load_spec, score_ex2, short, word_count

INK = "#1C2232"
COL = {"claim": "#FF9E80", "reason": "#FFE14D", "evidence": "#8FD0FF", "source": "#D6E0EE"}

CSS = """
<style>
.dva, .dva * {box-sizing:border-box}
.dva {color:%(ink)s; font-size:15px; max-width:980px}
.dva-card {background:#FFFFFF; color:%(ink)s; border:1px solid #C9CFDA; border-radius:10px; padding:14px 16px; margin:8px 0}
.dva-card h3, .dva-card h4 {margin:0 0 6px 0; color:%(ink)s; font-family:Georgia, 'Times New Roman', serif}
.dva-lead {font-size:16px; line-height:1.5; max-width:70ch; color:%(ink)s; background:#FFFFFF; padding:2px 0}
.dva-sent {font-family:Georgia, 'Times New Roman', serif; font-size:17px; line-height:1.5; color:%(ink)s; background:#FBFBF8;
           border:1px solid #DDE2EA; border-radius:8px; padding:8px 10px; margin-top:8px}
.dva-phrase {font-family:Georgia, 'Times New Roman', serif; font-size:16px; line-height:1.45; color:%(ink)s; padding:4px 0}
.dva-ptext {font-family:Georgia, 'Times New Roman', serif; font-size:17px; line-height:1.9; color:%(ink)s; background:#FBFBF8;
            border:1px solid #DDE2EA; border-radius:8px; padding:10px 12px; white-space:pre-wrap}
.dva-hl {color:%(ink)s; padding:1px 3px; border-radius:3px 6px 4px 7px; -webkit-box-decoration-break:clone; box-decoration-break:clone}
.dva-tag {display:inline-block; font-family:Arial, sans-serif; font-size:11px; font-weight:700; vertical-align:super; line-height:1;
          padding:2px 4px; border-radius:4px; background:%(ink)s; color:#FFFFFF; margin-left:3px}
.dva-fb {margin:6px 0; padding:8px 10px; border-radius:8px; border-left:5px solid; color:%(ink)s; line-height:1.45}
.dva-fb.ok {background:#E7F3EB; border-color:#1E6B3A} .dva-fb.bad {background:#FBEAEA; border-color:#A3262A}
.dva-fb.info {background:#EEF1F6; border-color:#6B7689}
.dva-fb b.ok {color:#1E6B3A} .dva-fb b.bad {color:#A3262A}
.dva-hint {color:#4B5567; font-size:14px}
.dva-done {display:inline-block; font-size:13px; font-weight:700; padding:1px 8px; border-radius:999px; background:#E7F3EB;
           color:#1E6B3A; border:1px solid #1E6B3A; margin-left:8px; vertical-align:middle; font-family:Arial, sans-serif}
.dva-defs {display:flex; gap:12px; flex-wrap:wrap; margin:8px 0}
.dva-def {flex:1 1 220px; border-radius:10px; padding:12px; color:%(ink)s}
.dva-notice {background:#EEF1F6; color:%(ink)s; border-radius:10px; padding:10px 14px; margin:8px 0}
.dva-parts button.widget-toggle-button, .dva-conf button.widget-toggle-button {min-height:36px; font-weight:700}
.dva-parts button.widget-toggle-button.mod-active {color:%(ink)s; outline:2px solid %(ink)s}
.dva-p3 button.widget-toggle-button:nth-of-type(1).mod-active {background:%(claim)s}
.dva-p3 button.widget-toggle-button:nth-of-type(2).mod-active {background:%(reason)s}
.dva-p3 button.widget-toggle-button:nth-of-type(3).mod-active {background:%(evidence)s}
.dva-p4 button.widget-toggle-button:nth-of-type(2).mod-active {background:%(claim)s}
.dva-p4 button.widget-toggle-button:nth-of-type(3).mod-active {background:%(reason)s}
.dva-p4 button.widget-toggle-button:nth-of-type(4).mod-active {background:%(evidence)s}
.dva textarea {font-family:Georgia, 'Times New Roman', serif; font-size:16px; line-height:1.5}
</style>
""" % {"ink": INK, **COL}


def esc(t) -> str:
    return html.escape(str(t), quote=True)


def fb(kind: str, verdict: str | None, text: str) -> str:
    v = f'<b class="{kind}">{esc(verdict)}</b> ' if verdict else ""
    return f'<div class="dva-fb {kind}">{v}{esc(text)}</div>'


def hl(text: str, part: str) -> str:
    return f'<span class="dva-hl" style="background:{COL[part]}">{esc(text)}<span class="dva-tag">{LABEL[part]}</span></span>'


def highlighted(text: str, spans: list[dict]) -> str:
    out, pos = [], 0
    for s in spans:
        out.append(esc(text[pos:s["start"]]))
        out.append(hl(text[s["start"]:s["end"]], s["part"]))
        pos = s["end"]
    out.append(esc(text[pos:]))
    return '<div class="dva-ptext">' + "".join(out) + "</div>"


def lay(**kw):
    return W.Layout(**kw)


# ========================================================================== exercise 1
class Ex1Para:
    def __init__(self, app, p: dict, index: int):
        self.app, self.p, self.index = app, p, index
        self.st = {"a1": {}, "a2": {}, "conf": "", "stage": "open"}
        self.box = W.VBox(layout=lay(width="100%"))
        self.box.add_class("dva-card")

    def restore(self, rec: dict):
        self.st = copy.deepcopy(rec)

    def render(self):
        p, st = self.p, self.st
        done = st["stage"] == "done"
        title = f'<h3>Paragraph {"ABC"[self.index]}: {esc(p["topic"])}{"<span class=dva-done>Done</span>" if done else ""}</h3>'
        kids = [W.HTML(title)]
        self.toggles = {}
        for i, s in enumerate(p["sentences"]):
            first, second = st["a1"].get(s["id"]), st["a2"].get(s["id"])
            right1 = first == s["key"]
            locked = done or (st["stage"] == "retry" and right1)
            value = first if st["stage"] == "open" or right1 else second
            tb = W.ToggleButtons(options=[(LABEL[k], k) for k in PARTS], value=value, disabled=locked,
                                 tooltips=[f"Sentence {i + 1} is a {LOWER[k]}" if k != "evidence" else f"Sentence {i + 1} is evidence" for k in PARTS],
                                 style={"button_width": "120px"})
            tb.add_class("dva-parts"); tb.add_class("dva-p3")
            tb.observe(lambda ch, sid=s["id"]: self.choose(sid, ch["new"]), names="value")
            self.toggles[s["id"]] = tb
            row = [W.HTML(f'<div class="dva-sent"><span style="color:#4B5567;font-family:Arial">{i + 1}.</span> {esc(s["text"])}</div>'), tb]
            if st["stage"] != "open":
                if right1:
                    row.append(W.HTML(fb("ok", "Correct.", s["right"])))
                elif st["stage"] == "retry":
                    row.append(W.HTML(fb("bad", "Not quite.", s["wrong"][first] + " Change your answer, then check again.")))
                elif second == s["key"]:
                    row.append(W.HTML(fb("ok", "Correct on your second try.", s["right"])))
                else:
                    row.append(W.HTML(fb("bad", f"The answer is {LOWER[s['key']]}.", s["wrong"].get(second) or s["wrong"].get(first, ""))))
            kids.append(W.VBox(row))
        if st["stage"] == "open":
            kids.append(W.HTML("<b>Before you check: how confident are you in your answers?</b>"))
            cf = W.ToggleButtons(options=[(l, k) for k, l in CONF], value=st["conf"] or None, style={"button_width": "170px"})
            cf.add_class("dva-conf")
            cf.observe(lambda ch: self.set_conf(ch["new"]), names="value")
            kids.append(cf)
        else:
            c = dict(CONF).get(st.get("conf"), "not given").lower()
            msg = f'Your confidence: {c}. First try: {st["s1"]} of {len(p["sentences"])} correct.'
            if done and st.get("s2") is not None:
                msg += f' After correcting: {st["s2"]} of {len(p["sentences"])}.'
            kids.append(W.HTML(f'<p class="dva-hint">{esc(msg)}</p>'))
        if not done:
            self.btn = W.Button(description="Check answers" if st["stage"] == "open" else "Check again", button_style="primary",
                                layout=lay(width="180px", height="40px"))
            self.btn.on_click(lambda _: self.check())
            self.hint = W.HTML()
            kids.append(W.HBox([self.btn, self.hint], layout=lay(align_items="center")))
            self.refresh_button()
        self.box.children = kids

    def choose(self, sid, value):
        (self.st["a1"] if self.st["stage"] == "open" else self.st["a2"])[sid] = value
        self.refresh_button()

    def set_conf(self, v):
        self.st["conf"] = v or ""
        self.refresh_button()

    def refresh_button(self):
        st, p = self.st, self.p
        if st["stage"] == "open":
            missing = sum(1 for s in p["sentences"] if not st["a1"].get(s["id"]))
        else:
            missing = sum(1 for s in p["sentences"] if st["a1"].get(s["id"]) != s["key"] and not st["a2"].get(s["id"]))
        need_conf = st["stage"] == "open" and not st["conf"]
        self.btn.disabled = missing > 0 or need_conf
        msg = f"Answer every sentence to check ({missing} left)." if missing else ("Choose how confident you are to check." if need_conf else "")
        self.hint.value = f'<span class="dva-hint">&nbsp; {esc(msg)}</span>'

    def check(self):
        st, p = self.st, self.p
        if st["stage"] == "open":
            st["s1"] = sum(1 for s in p["sentences"] if st["a1"].get(s["id"]) == s["key"])
            st["stage"] = "done" if st["s1"] == len(p["sentences"]) else "retry"
            if st["stage"] == "done":
                st["s2"] = st["s1"]
            else:
                for s in p["sentences"]:
                    if st["a1"].get(s["id"]) != s["key"]:
                        st["a2"][s["id"]] = st["a1"][s["id"]]
        else:
            st["s2"] = sum(1 for s in p["sentences"]
                           if (st["a1"][s["id"]] if st["a1"].get(s["id"]) == s["key"] else st["a2"].get(s["id"])) == s["key"])
            st["stage"] = "done"
        st["checkedAt"] = time.time()
        self.render()
        self.app.save("ex1", self.p["id"], self.st)


# ========================================================================== exercise 2
class Ex2Para:
    def __init__(self, app, p: dict, index: int):
        self.app, self.p, self.index = app, p, index
        self.st = {"m1": {}, "m2": {}, "nc1": False, "nc2": False, "conf": "", "stage": "open"}
        self.box = W.VBox(layout=lay(width="100%"))
        self.box.add_class("dva-card")

    def restore(self, rec):
        self.st = copy.deepcopy(rec)

    def marks(self):
        return self.st["m1"] if self.st["stage"] == "open" else self.st["m2"]

    def preview_html(self, marks):
        out = []
        for c in self.p["chunks"]:
            m = marks.get(c["id"])
            out.append(hl(c["text"], m) if m else esc(c["text"]))
        return '<div class="dva-ptext">' + " ".join(out) + "</div>"

    def render(self):
        p, st = self.p, self.st
        done = st["stage"] == "done"
        kids = [W.HTML(f'<h3>Paragraph {self.index + 1}: {esc(p["topic"])}{"<span class=dva-done>Done</span>" if done else ""}</h3>')]
        self.preview = W.HTML(self.preview_html(self.marks()))
        kids.append(self.preview)
        if not done:
            kids.append(W.HTML('<p class="dva-hint">Mark what each phrase does in the paragraph. The paragraph above shows your highlights.</p>'))
            for i, c in enumerate(p["chunks"]):
                tb = W.ToggleButtons(options=[("No highlight", "none")] + [(LABEL[k], k) for k in PARTS],
                                     value=self.marks().get(c["id"], "none"), style={"button_width": "110px"})
                tb.add_class("dva-parts"); tb.add_class("dva-p4")
                tb.observe(lambda ch, cid=c["id"]: self.mark(cid, ch["new"]), names="value")
                kids.append(W.VBox([W.HTML(f'<div class="dva-phrase"><span style="color:#4B5567;font-family:Arial">Phrase {i + 1}:</span> {esc(c["text"])}</div>'), tb],
                                   layout=lay(margin="4px 0 8px 0")))
        nc_val = st["nc1"] if st["stage"] == "open" else st["nc2"]
        self.nc = W.Checkbox(value=nc_val, description="This paragraph has no claim", disabled=done, indent=False)
        self.nc.observe(lambda ch: self.set_nc(ch["new"]), names="value")
        kids.append(self.nc)
        if st["stage"] == "open":
            kids.append(W.HTML("<b>Before you check: how confident are you in your answers?</b>"))
            cf = W.ToggleButtons(options=[(l, k) for k, l in CONF], value=st["conf"] or None, style={"button_width": "170px"})
            cf.add_class("dva-conf")
            cf.observe(lambda ch: self.set_conf(ch["new"]), names="value")
            kids.append(cf)
        if st["stage"] != "open":
            kids.append(W.HTML(self.feedback_html()))
        if not done:
            self.btn = W.Button(description="Check" if st["stage"] == "open" else "Check again", button_style="primary",
                                layout=lay(width="160px", height="40px"))
            self.btn.on_click(lambda _: self.check())
            row = [self.btn]
            if st["stage"] == "retry":
                show = W.Button(description="Show the model answer", layout=lay(width="210px", height="40px"))
                show.on_click(lambda _: self.reveal())
                row.append(show)
            self.hint = W.HTML()
            row.append(self.hint)
            kids.append(W.HBox(row, layout=lay(align_items="center")))
            self.refresh_button()
        if done:
            kids.append(W.HTML(self.model_html()))
        self.box.children = kids

    def mark(self, cid, value):
        m = self.marks()
        if value == "none":
            m.pop(cid, None)
        else:
            m[cid] = value
        self.preview.value = self.preview_html(m)
        self.refresh_button()

    def set_nc(self, v):
        if self.st["stage"] == "open":
            self.st["nc1"] = v
        else:
            self.st["nc2"] = v
        self.refresh_button()

    def set_conf(self, v):
        self.st["conf"] = v or ""
        self.refresh_button()

    def refresh_button(self):
        st = self.st
        nc = st["nc1"] if st["stage"] == "open" else st["nc2"]
        anything = bool(self.marks()) or nc
        need_conf = st["stage"] == "open" and not st["conf"]
        self.btn.disabled = not anything or need_conf
        msg = ("Highlight at least one phrase, or tick “This paragraph has no claim”, to check." if not anything
               else ("Choose how confident you are to check." if need_conf else ""))
        self.hint.value = f'<span class="dva-hint">&nbsp; {esc(msg)}</span>'

    def check(self):
        st, p = self.st, self.p
        if st["stage"] == "open":
            r = score_ex2(p, st["m1"], st["nc1"])
            st["acc1"], st["parts1"] = r["acc"], r["parts"]
            st["m2"], st["nc2"] = dict(st["m1"]), st["nc1"]
            if r["all_right"]:
                st["stage"], st["acc2"] = "done", r["acc"]
            else:
                st["stage"] = "retry"
        else:
            st["acc2"] = score_ex2(p, st["m2"], st["nc2"])["acc"]
            st["stage"] = "done"
        self.finish()

    def reveal(self):
        self.st["stage"], self.st["revealedEarly"] = "done", True
        self.finish()

    def finish(self):
        self.st["checkedAt"] = time.time()
        self.render()
        self.app.save("ex2", self.p["id"], self.st)

    def feedback_html(self):
        p, st = self.p, self.st
        marks = st["m1"] if st["stage"] == "retry" else st["m2"]
        nc = st["nc1"] if st["stage"] == "retry" else st["nc2"]
        r = score_ex2(p, marks, nc)
        if r["all_right"]:
            first_ok = st["stage"] == "done" and st.get("acc1") == 1
            return fb("ok", "All correct." if first_ok else "All correct now.", p.get("noClaimRight") if p["noClaim"] else "Your highlights match the model answer.")
        out = []
        rows = [k for k in PARTS if r["parts"][k] is not None]
        if rows:
            items = " &nbsp; ".join(f'<b class="{"ok" if r["parts"][k] else "bad"}">{"✓" if r["parts"][k] else "✗"} {LABEL[k]}: '
                                    f'{"right" if r["parts"][k] else "not quite"}</b>' for k in rows)
            out.append(f'<div class="dva-fb bad">{items}</div>')
        for c in p["chunks"]:
            m = marks.get(c["id"], "none")
            if m != c["key"]:
                did = "you didn’t highlight this" if m == "none" else f"you marked this as {LOWER[m]}"
                out.append(fb("info", None, f"“{short(c['text'])}” – {did}. {c['why']}"))
        if p["noClaim"] and not nc:
            out.append(fb("info", None, "This paragraph makes no claim, so tick “This paragraph has no claim”. " + p["noClaimRight"].replace("Right: ", "")))
        if not p["noClaim"] and nc:
            cl = next(c for c in p["chunks"] if c["key"] == "claim")
            out.append(fb("info", None, f"This paragraph does have a claim: “{short(cl['text'], 12)}”"))
        if st["stage"] == "retry":
            out.append('<p class="dva-hint">Change your highlights and check again, or show the model answer.</p>')
        return "".join(out)

    def model_html(self):
        p, st = self.p, self.st
        parts = [hl(c["text"], c["key"]) if c["key"] != "none" else esc(c["text"]) for c in p["chunks"]]
        out = '<h4 style="margin-top:10px">Model answer</h4><div class="dva-ptext">' + " ".join(parts) + "</div>"
        if p["noClaim"]:
            out += "<p>No highlights: this paragraph has no claim, so its facts aren’t working as evidence.</p>"
        if st.get("acc1") != 1:
            msg = f"First try: {round(st['acc1'] * 100)}% of phrases marked correctly."
            if st.get("acc2") is not None and not st.get("revealedEarly"):
                msg += f" Second try: {round(st['acc2'] * 100)}%."
            out += f'<p class="dva-hint">{esc(msg)}</p>'
        return out


# ========================================================================== exercise 3
class Ex3:
    def __init__(self, app):
        self.app = app
        self.spec = app.spec["ex3"]
        self.subs = []
        self.box = W.VBox(layout=lay(width="100%"))
        self.text = W.Textarea(placeholder="Paste one paragraph here", layout=lay(width="100%", height="200px"))
        self.claim = W.Textarea(placeholder="Write your claim in one sentence", layout=lay(width="100%", height="60px"))
        self.count = W.HTML()
        self.btn = W.Button(description="Get feedback", button_style="primary", layout=lay(width="180px", height="40px"))
        self.hint = W.HTML()
        self.usage = W.HTML()
        self.status = W.HTML()
        self.results = W.VBox()
        self.remaining = None
        self.busy = False
        self.text.observe(lambda _: self.refresh(), names="value")
        self.claim.observe(lambda _: self.refresh(), names="value")
        self.btn.on_click(lambda _: self.request())

    def render(self):
        cfg = self.spec
        lead = (f"Paste one paragraph from an essay or draft of your own, between {cfg['minWords']} and {cfg['maxWords']} words. "
                "Before you ask for feedback, write down what you think the paragraph’s claim is. Claude will highlight the claim, "
                "reasons and evidence it finds and give you pointers. It won’t rewrite your paragraph: the changes are yours to make.")
        card = W.VBox([W.HTML("<b>Your paragraph</b>"), self.text, self.count,
                       W.HTML("<b>In one sentence, in your own words: what is this paragraph’s claim?</b>"), self.claim,
                       W.HTML('<p class="dva-hint">If you’re not sure it has a claim, say so.</p>'),
                       W.HBox([self.btn, self.hint], layout=lay(align_items="center")), self.usage, self.status])
        card.add_class("dva-card")
        self.box.children = [W.HTML(f'<h2>Exercise 3: Your paragraph</h2><p class="dva-lead">{esc(lead)}</p>'), card, self.results]
        self.update_usage()
        self.draw_results()
        self.refresh()

    def update_usage(self):
        try:
            u = client.usage("paragraph-feedback", self.app.user)
            self.remaining = u["remaining"]
            self.usage.value = f'<p class="dva-hint">Feedback requests used: {u["used"]} of {u["limit"]}.</p>'
        except client.GatewayError as e:
            self.remaining = None
            self.usage.value = fb("bad", None, e.message)

    def refresh(self):
        n = word_count(self.text.value)
        cfg = self.spec
        self.count.value = f'<p class="dva-hint">{n} word{"" if n == 1 else "s"} ({cfg["minWords"]}–{cfg["maxWords"]})</p>'
        why = ""
        last = self.subs[-1] if self.subs else None
        if self.remaining is None:
            why = "Feedback isn’t available until the gateway is running."
        elif self.remaining <= 0:
            why = "You’ve used all your feedback requests."
        elif n < cfg["minWords"]:
            why = f"Paste at least {cfg['minWords']} words."
        elif n > cfg["maxWords"]:
            why = f"Shorten your paragraph to {cfg['maxWords']} words or fewer."
        elif word_count(self.claim.value) < 3:
            why = "Write your claim in one sentence first."
        elif last and last["text"].strip() == self.text.value.strip() and last["stated"].strip() == self.claim.value.strip():
            why = "Revise your paragraph or your claim before asking again."
        self.btn.disabled = bool(why) or self.busy
        self.hint.value = "" if self.busy else f'<span class="dva-hint">&nbsp; {esc(why)}</span>'

    def request(self):
        self.busy = True
        self.refresh()
        self.status.value = '<p class="dva-hint">Claude is reading your paragraph…</p>'
        text, stated = self.text.value, self.claim.value
        try:
            r = client.run_template("paragraph-feedback", {"PARAGRAPH": text, "STATED_CLAIM": stated}, user=self.app.user)
            result = clean_result(r["output"], text)
            sub = {"id": "s" + str(int(time.time() * 1000)), "text": text, "stated": stated, "result": result,
                   "at": time.time(), "attempt": len(self.subs) + 1, "callId": r["call_id"], "mode": r["mode"],
                   "specId": self.app.spec["id"]}
            self.subs.append(sub)
            self.app.save("ex3", sub["id"], sub)
            self.status.value = ""
        except client.GatewayError as e:
            self.status.value = fb("bad", None, e.message)
        self.busy = False
        self.update_usage()
        self.draw_results()
        self.refresh()
        self.app.update_progress()

    def draw_results(self):
        cards = []
        for n, s in reversed(list(enumerate(self.subs, 1))):
            r = s["result"]
            found = "".join(f'<li style="margin:3px 0"><span class="dva-hl" style="background:{COL[k]};font-weight:700">{LABEL[k]}</span> '
                            f'{(str(c) + " found") if (c := sum(1 for x in r["spans"] if x["part"] == k)) else "Not found"}</li>' for k in PARTS)
            dropped = (f'<p class="dva-hint">Claude quoted {r["dropped"]} passage{"s" if r["dropped"] > 1 else ""} that didn’t match your text exactly, '
                       f'so {"they aren’t" if r["dropped"] > 1 else "it isn’t"} highlighted.</p>') if r["dropped"] else ""
            sample = ('<p class="dva-notice"><b>Sample feedback.</b> The gateway has no API key, so this feedback was made by simple rules, not by Claude.</p>'
                      if s.get("mode") == "sample" else "")
            pointers = "".join(f"<li>{esc(p)}</li>" for p in r["pointers"])
            when = time.strftime("%d %b, %H:%M", time.localtime(s["at"]))
            cards.append(W.HTML(
                f'<div class="dva-card"><h3>Feedback on version {n}</h3><p class="dva-hint">{when}</p>{sample}'
                f'<h4>Your paragraph, as Claude read it</h4>{highlighted(s["text"], r["spans"])}{dropped}'
                f'<h4>What Claude found</h4><ul style="list-style:none;padding:0;margin:0">{found}</ul>'
                f'<h4>Your claim and Claude’s reading</h4><p><b>You said:</b> {esc(s["stated"])}</p>'
                f'<p>{esc(MATCH[r["claim_match"]["level"]] + " " + r["claim_match"]["comment"])}</p>'
                f'<h4>Overall</h4><p><b>{esc(TYPE[r["overall"]["type"]])}.</b> {esc(r["overall"]["comment"])}</p>'
                + (f"<h4>Pointers</h4><ul>{pointers}</ul>" if pointers else "")
                + '<p class="dva-notice">AI feedback can be wrong. If Claude misreads your paragraph, that’s worth noticing too: '
                  "a reader might misread it the same way. To try again, revise your paragraph above and request feedback.</p></div>"))
        self.results.children = cards


# ========================================================================== the app
class StudentActivity:
    def __init__(self):
        self.spec = load_spec()
        self.user = None
        self.progress = W.HTML()
        self.gateway_status = W.HTML()
        self.tabs = W.Tab(layout=lay(width="100%"))
        self.root = W.VBox([W.HTML(CSS), W.HTML('<h1 style="font-family:Georgia,serif;margin:4px 0">Descriptive or analytical?</h1>'
                                                '<p class="dva-hint">Technical demo by Steven Williams, AI and Education Specialist, '
                                                'showing constrained LLM use through a gateway. The content is a quick draft and hasn’t been checked.</p>'),
                            self.progress, self.tabs], layout=lay(width="100%"))
        self.root.add_class("dva")
        self.ex1 = [Ex1Para(self, p, i) for i, p in enumerate(self.spec["ex1"])]
        self.ex2 = [Ex2Para(self, p, i) for i, p in enumerate(self.spec["ex2"])]
        self.ex3 = Ex3(self)
        self.save_status = W.HTML()
        self.build()

    # ---------------------------------------------------------------- layout
    def nav(self, i):
        b = []
        if i > 0:
            back = W.Button(description="← Back", layout=lay(width="120px", height="40px"))
            back.on_click(lambda _: setattr(self.tabs, "selected_index", i - 1))
            b.append(back)
        b.append(W.HTML("", layout=lay(flex="1")))
        if i < 3:
            nxt = W.Button(description="Next →", button_style="primary", layout=lay(width="120px", height="40px"))
            nxt.on_click(lambda _: setattr(self.tabs, "selected_index", i + 1))
            b.append(nxt)
        return W.HBox(b, layout=lay(width="100%", margin="16px 0 0 0"))

    def start_tab(self):
        defs = "".join(f'<div class="dva-def" style="background:{COL[k]}"><b>{self.spec["parts"][k]["label"]}</b><br>'
                       f'{esc(self.spec["parts"][k]["definition"][0].upper() + self.spec["parts"][k]["definition"][1:])}.</div>' for k in PARTS)
        intro = W.HTML(
            '<h2>Claims, reasons and evidence</h2><p class="dva-lead">Descriptive writing reports what happened, or what others have said. '
            "Analytical writing uses that material to argue a position. An analytical paragraph usually has three parts:</p>"
            f'<div class="dva-defs">{defs}</div>'
            '<div class="dva-card"><h3>What you’ll do</h3><ol>'
            "<li><b>Sort sentences.</b> Decide whether each sentence in three short paragraphs is a claim, a reason or evidence.</li>"
            "<li><b>Highlight paragraphs.</b> Mark the claim, reasons and evidence in four example paragraphs.</li>"
            "<li><b>Your paragraph.</b> Paste a paragraph of your own and get feedback from Claude, an AI model, on its structure.</li></ol>"
            '<p class="dva-hint">Exercises 1 and 2 are marked against fixed answers, so the feedback is the same for everyone.</p></div>'
            '<div class="dva-notice"><h3 style="margin:0 0 4px 0">What’s saved, and who can see it</h3>'
            "<p>Your answers in all three exercises are saved and can be seen by your course teachers. That includes any paragraph you paste "
            "into exercise 3, your statement of its claim, and the feedback you receive.</p>"
            "<p>In exercise 3, your paragraph is sent to Claude through the course’s gateway to generate the feedback. "
            "Don’t paste anything you wouldn’t want your teachers to read.</p></div>")
        self.name = W.Text(placeholder="For example, Ada Lovelace", layout=lay(width="320px"))
        self.sign_btn = W.Button(description="Sign in", button_style="primary", layout=lay(width="120px", height="36px"))
        self.sign_btn.on_click(lambda _: self.sign_in())
        sign = W.VBox([W.HTML("<h3>Sign in</h3><p>Type your name. In this demo it identifies your work to the gateway; "
                              "on a university system you’d be signed in automatically.</p>"),
                       W.HBox([self.name, self.sign_btn]), self.save_status, self.gateway_status])
        sign.add_class("dva-card")
        return W.VBox([intro, sign, self.nav(0)])

    def build(self):
        try:
            from .gateway_runner import describe
            self.gateway_status.value = f'<p class="dva-hint">Gateway: {esc(describe(client.health()))}.</p>'
        except client.GatewayError as e:
            self.gateway_status.value = fb("bad", None, e.message)
        waiting = lambda: W.HTML('<p class="dva-lead">Sign in on the Start tab first.</p>')
        self.tabs.children = [self.start_tab(), waiting(), waiting(), waiting()]
        self.titles = ["Start", "1. Sort sentences", "2. Highlight paragraphs", "3. Your paragraph"]
        for i, t in enumerate(self.titles):
            self.tabs.set_title(i, t)
        self.update_progress()

    def sign_in(self):
        name = self.name.value.strip()
        if not name:
            self.save_status.value = fb("bad", None, "Type your name to sign in.")
            return
        self.user = name
        try:
            rows = client.my_results(name)
        except client.GatewayError as e:
            self.save_status.value = fb("bad", None, e.message)
            self.user = None
            return
        latest = {}
        for r in rows:
            latest[(r["exercise"], r["item"])] = r["record"]
        for e in self.ex1:
            if ("ex1", e.p["id"]) in latest:
                e.restore(latest[("ex1", e.p["id"])])
        for e in self.ex2:
            if ("ex2", e.p["id"]) in latest:
                e.restore(latest[("ex2", e.p["id"])])
        self.ex3.subs = [r["record"] for r in rows if r["exercise"] == "ex3"]
        if self.ex3.subs:
            self.ex3.text.value, self.ex3.claim.value = self.ex3.subs[-1]["text"], self.ex3.subs[-1]["stated"]
        self.name.disabled = self.sign_btn.disabled = True
        self.save_status.value = f'<p>Signed in as <b>{esc(name)}</b>.' + (" Your earlier answers are loaded." if rows else "") + "</p>"
        for e in self.ex1 + self.ex2:
            e.render()
        self.ex3.render()
        t1 = W.VBox([W.HTML('<h2>Exercise 1: Sort sentences</h2><p class="dva-lead">Each paragraph below is split into its sentences. '
                            "Decide what each sentence does in its paragraph: is it the claim, a reason or evidence? Then say how confident "
                            "you are and check your answers. You can correct any you get wrong once.</p>")] + [e.box for e in self.ex1] + [self.nav(1)])
        t2 = W.VBox([W.HTML('<h2>Exercise 2: Highlight paragraphs</h2><p class="dva-lead">For each phrase, choose whether it’s the claim, '
                            "a reason, evidence, or none of these. Not every phrase needs a highlight, and a paragraph may have no claim at all.</p>")]
                    + [e.box for e in self.ex2] + [self.nav(2)])
        t3 = W.VBox([self.ex3.box, self.nav(3)])
        self.tabs.children = [self.tabs.children[0], t1, t2, t3]
        for i, t in enumerate(self.titles):
            self.tabs.set_title(i, t)
        self.update_progress()

    # ---------------------------------------------------------------- saving
    def save(self, exercise, item, record):
        try:
            client.save_result(self.user, exercise, item, record)
            self.save_status.value = f'<p>Signed in as <b>{esc(self.user)}</b>. Saved.</p>'
        except client.GatewayError as e:
            self.save_status.value = fb("bad", None, "Couldn’t save: " + e.message)
        self.update_progress()

    def done(self, n):
        if n == 1:
            return all(e.st["stage"] == "done" for e in self.ex1)
        if n == 2:
            return all(e.st["stage"] == "done" for e in self.ex2)
        return bool(self.ex3.subs)

    def update_progress(self):
        d = [n for n in (1, 2, 3) if self.done(n)]
        self.progress.value = f'<p><b>Exercises completed: {len(d)} of 3</b></p>'
        if hasattr(self, "titles"):
            for n in (1, 2, 3):
                self.tabs.set_title(n, self.titles[n] + (" ✓" if n in d else ""))

    def show(self):
        display(self.root)

"""Marking, matching and analysis rules shared by the student and teacher notebooks.

These follow the same rules as the claude.ai artifact version, so both
versions mark answers the same way and save records in the same shape.
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PARTS = ["claim", "reason", "evidence"]
LABEL = {"claim": "Claim", "reason": "Reason", "evidence": "Evidence", "none": "No highlight"}
LOWER = {"claim": "claim", "reason": "reason", "evidence": "evidence", "none": "nothing"}
CONF = [("very", "Very confident"), ("fairly", "Fairly confident"), ("not", "Not very confident")]
MATCH = {"matches": "Your claim matches what Claude found.", "partly": "Your claim partly matches what Claude found.",
         "differs": "Your claim differs from what Claude found.", "no_claim": "Claude didn’t find a claim in your paragraph."}
TYPE = {"descriptive": "Mainly descriptive", "mixed": "A mix of description and analysis", "analytical": "Mainly analytical"}


def load_spec() -> dict:
    return json.loads((ROOT / "activity" / "activity_spec.json").read_text(encoding="utf-8"))


def short(text: str, n: int = 9) -> str:
    w = text.split()
    return text if len(w) <= n else " ".join(w[:n]) + "…"


def word_count(text: str) -> int:
    return len(text.split())


# ----------------------------------------------------------------- exercise 2
def score_ex2(para: dict, marks: dict, no_claim: bool) -> dict:
    ok = sum(1 for c in para["chunks"] if marks.get(c["id"], "none") == c["key"])
    if bool(no_claim) == bool(para["noClaim"]):
        ok += 1
    parts = {}
    for k in PARTS:
        kc = [c for c in para["chunks"] if c["key"] == k]
        mc = [c for c in para["chunks"] if marks.get(c["id"]) == k]
        parts[k] = None if not kc and not mc else (all(marks.get(c["id"]) == k for c in kc) and all(c["key"] == k for c in mc))
    total = len(para["chunks"]) + 1
    return {"acc": ok / total, "all_right": ok == total, "parts": parts}


# ----------------------------------------------------------------- exercise 3
def _norm(s: str) -> str:
    return s.replace("‘", "'").replace("’", "'").replace("“", '"').replace("”", '"')


def clean_result(raw: dict, text: str) -> dict:
    """Keep only quotes that appear in the student's text, without overlaps."""
    out = {"spans": [], "missing": [], "claim_match": {"level": "differs", "comment": ""},
           "pointers": [], "overall": {"type": "mixed", "comment": ""}, "dropped": 0}
    nt = _norm(text)
    lt = nt.lower()
    found = []
    for sp in raw.get("spans") or []:
        if not isinstance(sp, dict) or sp.get("part") not in PARTS or not str(sp.get("quote", "")).strip():
            continue
        q = _norm(str(sp["quote"]).strip())
        i = nt.find(q)
        if i < 0:
            i = lt.find(q.lower())
        if i < 0:
            out["dropped"] += 1
            continue
        found.append({"part": sp["part"], "start": i, "end": i + len(q), "quote": text[i:i + len(q)]})
    found.sort(key=lambda f: f["start"])
    for f in found:
        if out["spans"] and f["start"] < out["spans"][-1]["end"]:
            out["dropped"] += 1
            continue
        out["spans"].append(f)
    out["missing"] = [m for m in (raw.get("missing") or []) if m in PARTS]
    for k in PARTS:
        if not any(s["part"] == k for s in out["spans"]) and k not in out["missing"]:
            out["missing"].append(k)
    cm = raw.get("claim_match") or {}
    if cm.get("level") in MATCH:
        out["claim_match"] = {"level": cm["level"], "comment": str(cm.get("comment", ""))}
    out["pointers"] = [p for p in (raw.get("pointers") or []) if isinstance(p, str) and p.strip()][:3]
    ov = raw.get("overall") or {}
    if ov.get("type") in TYPE:
        out["overall"] = {"type": ov["type"], "comment": str(ov.get("comment", ""))}
    return out


# ----------------------------------------------------------------- teacher analysis
def latest_by_student(results: list[dict]) -> dict:
    """Fold the gateway's result rows into {user: {"ex1": {...}, "ex2": {...}, "ex3": [...], "last": t}}."""
    S = {}
    for r in sorted(results, key=lambda r: r["at"]):
        s = S.setdefault(r["user"], {"ex1": {}, "ex2": {}, "ex3": [], "last": 0})
        s["last"] = max(s["last"], r["at"])
        if r["exercise"] == "ex3":
            s["ex3"].append(r["record"])
        else:
            s[r["exercise"]][r["item"]] = r["record"]
    return S


def pct(a: int, b: int) -> int:
    return round(100 * a / b) if b else 0


def analyse(spec: dict, S: dict) -> dict:
    A = {}
    confusion = {a: {b: 0 for b in PARTS} for a in PARTS}
    conf = {k: [0, 0] for k, _ in CONF}
    items = []
    for p in spec["ex1"]:
        for s in p["sentences"]:
            it = {"p": p, "s": s, "n": 0, "right": 0, "wrong": {k: 0 for k in PARTS}}
            for st in S.values():
                r = st["ex1"].get(p["id"])
                if not r or r.get("s1") is None:
                    continue
                a = r.get("a1", {}).get(s["id"])
                if not a:
                    continue
                it["n"] += 1
                if a == s["key"]:
                    it["right"] += 1
                else:
                    it["wrong"][a] += 1
                confusion[s["key"]][a] += 1
            items.append(it)
    for st in S.values():
        for p in spec["ex1"]:
            r = st["ex1"].get(p["id"])
            if r and r.get("s1") is not None and r.get("conf") in conf:
                conf[r["conf"]][0] += r["s1"]
                conf[r["conf"]][1] += len(p["sentences"])
    A["ex1"] = {"items": items, "confusion": confusion, "conf": conf}

    paras = []
    for p in spec["ex2"]:
        row = {"p": p, "n": 0, "all_right": 0, "parts": {k: [0, 0] for k in PARTS}, "nc": [0, 0],
               "chunks": {c["id"]: {"c": c, "wrong": 0, "as": {}} for c in p["chunks"]}}
        for st in S.values():
            r = st["ex2"].get(p["id"])
            if not r or r.get("acc1") is None:
                continue
            row["n"] += 1
            if r["acc1"] == 1:
                row["all_right"] += 1
            sc = score_ex2(p, r.get("m1", {}), r.get("nc1", False))
            for k in PARTS:
                if sc["parts"][k] is not None and any(c["key"] == k for c in p["chunks"]):
                    row["parts"][k][1] += 1
                    row["parts"][k][0] += 1 if sc["parts"][k] else 0
            row["nc"][1] += 1
            row["nc"][0] += 1 if bool(r.get("nc1")) == bool(p["noClaim"]) else 0
            for c in p["chunks"]:
                m = r.get("m1", {}).get(c["id"], "none")
                if m != c["key"]:
                    row["chunks"][c["id"]]["wrong"] += 1
                    row["chunks"][c["id"]]["as"][m] = row["chunks"][c["id"]]["as"].get(m, 0) + 1
        paras.append(row)
    A["ex2"] = {"paras": paras}

    subs = [(u, x, i) for u, st in S.items() for i, x in enumerate(st["ex3"]) if x.get("result")]
    firsts = [st["ex3"][0] for st in S.values() if st["ex3"]]
    lasts = [st["ex3"][-1] for st in S.values() if st["ex3"]]
    A["ex3"] = {
        "subs": subs, "firsts": firsts,
        "missing": {k: sum(1 for x in firsts if k in x["result"]["missing"]) for k in PARTS},
        "match": {k: sum(1 for x in firsts if x["result"]["claim_match"]["level"] == k) for k in MATCH},
        "type_first": {k: sum(1 for x in firsts if x["result"]["overall"]["type"] == k) for k in TYPE},
        "type_last": {k: sum(1 for x in lasts if x["result"]["overall"]["type"] == k) for k in TYPE},
        "revised": sum(1 for st in S.values() if len(st["ex3"]) > 1),
    }
    return A


def data_bullets(A: dict) -> list[str]:
    out = []
    conf = A["ex1"]["confusion"]
    pairs = [(conf[a][b], a, b) for a in PARTS for b in PARTS if a != b and conf[a][b] > 0]
    total_wrong = sum(n for n, _, _ in pairs)
    if pairs:
        n, a, b = max(pairs)
        target = "evidence" if b == "evidence" else "a " + LOWER[b]
        out.append(f"Exercise 1: the most common mistake was sorting a {LOWER[a]} as {target} ({n} of {total_wrong} wrong first answers).")
    answered = [i for i in A["ex1"]["items"] if i["n"]]
    if answered:
        hard = min(answered, key=lambda i: i["right"] / i["n"])
        kind = "piece of evidence" if hard["s"]["key"] == "evidence" else LOWER[hard["s"]["key"]]
        out.append(f"Exercise 1: the hardest sentence was “{short(hard['s']['text'], 10)}” (a {kind}): "
                   f"{hard['right']} of {hard['n']} students got it right first time.")
    cv, cn = A["ex1"]["conf"]["very"], A["ex1"]["conf"]["not"]
    if cv[1] and cn[1]:
        out.append(f"Exercise 1: students who felt very confident got {pct(*cv)}% of sentences right first time; "
                   f"students who felt not very confident got {pct(*cn)}%.")
    tot = {k: [0, 0] for k in PARTS}
    for r in A["ex2"]["paras"]:
        for k in PARTS:
            tot[k][0] += r["parts"][k][0]
            tot[k][1] += r["parts"][k][1]
    have = [k for k in PARTS if tot[k][1]]
    if have:
        weak = min(have, key=lambda k: tot[k][0] / tot[k][1])
        name = "evidence" if weak == "evidence" else LOWER[weak] + "s"
        out.append(f"Exercise 2: students were least accurate at marking {name}: {tot[weak][0]} of {tot[weak][1]} "
                   f"paragraph attempts marked it exactly right first time.")
    summ = next((r for r in A["ex2"]["paras"] if r["p"]["noClaim"]), None)
    if summ and summ["n"]:
        out.append(f"Exercise 2: {summ['nc'][0]} of {summ['n']} students recognised that the paragraph on "
                   f"{summ['p']['topic'][0].lower() + summ['p']['topic'][1:]} has no claim.")
    f = len(A["ex3"]["firsts"])
    if f:
        m = A["ex3"]["missing"]
        out.append(f"Exercise 3: in students’ first submissions, Claude found no reason in {m['reason']} of {f}, "
                   f"no evidence in {m['evidence']} of {f}, and no claim in {m['claim']} of {f}.")
        mt = A["ex3"]["match"]
        out.append(f"Exercise 3: students’ own statement of their claim matched Claude’s reading in {mt['matches']} of {f} "
                   f"first submissions, partly matched in {mt['partly']}, and differed in {mt['differs']}.")
        rev = A["ex3"]["revised"]
        out.append(f"Exercise 3: Claude rated {A['ex3']['type_first']['descriptive']} of {f} first submissions as mainly descriptive"
                   + (f"; {rev} student{'s' if rev > 1 else ''} revised and resubmitted." if rev else "."))
    return out

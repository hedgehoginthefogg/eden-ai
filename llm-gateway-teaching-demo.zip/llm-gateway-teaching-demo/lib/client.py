"""Talks to the gateway. The notebook holds no API key and no prompts:
it can only ask the gateway to run a registered template."""
import os
import requests

GATEWAY_URL = os.environ.get("GATEWAY_URL", "http://127.0.0.1:8000").rstrip("/")
TEACHER_TOKEN = os.environ.get("TEACHER_TOKEN", "demo-teacher-token")


class GatewayError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status
        self.message = message


def _call(method: str, path: str, *, user: str | None = None, teacher: bool = False, json=None, timeout=120):
    headers = {}
    if user:
        headers["X-Demo-User"] = user
    if teacher:
        headers["X-Teacher-Token"] = TEACHER_TOKEN
    try:
        r = requests.request(method, GATEWAY_URL + path, headers=headers, json=json, timeout=timeout)
    except requests.RequestException:
        raise GatewayError(0, "The gateway isn’t running. Open 0_start_gateway.ipynb and run it first.")
    if r.status_code >= 400:
        try:
            msg = r.json().get("detail", r.text)
        except ValueError:
            msg = r.text
        raise GatewayError(r.status_code, str(msg))
    return r.json()


def health():
    return _call("GET", "/health", timeout=5)


def run_template(template_id: str, variables: dict, user: str | None = None, teacher: bool = False):
    return _call("POST", f"/v1/run/{template_id}", user=user, teacher=teacher, json={"variables": variables})


def usage(template_id: str, user: str):
    return _call("GET", f"/v1/usage/{template_id}", user=user)


def save_result(user: str, exercise: str, item: str, record: dict):
    return _call("POST", "/v1/results", user=user, json={"exercise": exercise, "item": item, "record": record})


def my_results(user: str):
    return _call("GET", "/v1/my-results", user=user)


def all_results():
    return _call("GET", "/admin/results", teacher=True)


def all_calls(limit: int = 500):
    return _call("GET", f"/admin/calls?limit={limit}", teacher=True)


def all_refusals():
    return _call("GET", "/admin/refusals", teacher=True)


def templates():
    return _call("GET", "/v1/templates")

"""Starts the reference gateway as a separate background process on this machine."""
import os
import subprocess
import sys
import time
from pathlib import Path

from . import client

ROOT = Path(__file__).resolve().parent.parent
LOG = ROOT / "gateway" / "gateway_server.log"


def start(port: int = 8000) -> str:
    try:
        h = client.health()
        return f"The gateway is already running ({describe(h)})."
    except client.GatewayError:
        pass
    env = dict(os.environ)
    with open(LOG, "ab") as log:
        subprocess.Popen([sys.executable, "-m", "uvicorn", "gateway.app:app", "--host", "127.0.0.1", "--port", str(port)],
                         cwd=ROOT, env=env, stdout=log, stderr=log, start_new_session=True)
    for _ in range(40):
        time.sleep(0.25)
        try:
            return f"The gateway has started ({describe(client.health())})."
        except client.GatewayError:
            continue
    return f"The gateway didn’t start. See {LOG.name} in the gateway folder for the error."


def stop() -> str:
    r = subprocess.run(["pkill", "-f", "uvicorn gateway.app:app"], capture_output=True)
    return "The gateway has stopped." if r.returncode == 0 else "The gateway wasn’t running."


def describe(h: dict) -> str:
    if h.get("mode") == "live":
        return f"live mode, using {h.get('model')}"
    return "sample mode: no API key is set, so feedback is example output made by simple rules"

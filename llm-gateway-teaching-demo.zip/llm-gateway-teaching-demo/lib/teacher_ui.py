"""Teacher dashboard: collects results and LLM logs from the gateway."""
import json
import time

import ipywidgets as W
from IPython.display import display

from . import client
from .core import CONF, LABEL, LOWER, MATCH, PARTS, TYPE, analyse, data_bullets, latest_by_student, load_spec, pct, short
from .student_ui import CSS, esc, fb, highlighted


def table(head, rows, num=()):
    th = "".join(f'<th style="text-align:{"right" if i in num else "left"}">{esc(h)}</th>' for i, h in enumerate(head))
    body = ""
    for r in rows:
        cells = "".join((f"<th scope=row>{c}</th>" if i == 0 else f'<td style="text-align:{"right" if i in num else "left"}">{c}</td>')
                        for i, c in enumerate(r))
        body += f"<tr>{cells}</tr>"
    return (f'<div style="overflow-x:auto"><table class="dva-table"><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table></div>')


TABLE_CSS = """<style>
.dva-table {border-collapse:collapse; width:100%; background:#FFFFFF; color:#1C2232; margin:6px 0 14px 0}
.dva-table th, .dva-table td {border:1px solid #C9CFDA; padding:6px 8px; vertical-align:top; font-size:14px}
.dva-table thead th {background:#EEF1F6}
.dva-table th {text-align:left}
.dva-table tbody th {font-weight:400}
.dva-section {background:#FFFFFF; color:#1C2232; padding:4px 2px}
</style>"""


class TeacherDashboard:
    def __init__(self):
        self.spec = load_spec()
        self.S, self.calls, self.insights = {}, [], []
        self.status = W.HTML()
        self.load_btn = W.Button(description="Load results", button_style="primary", layout=W.Layout(width="160px", height="40px"))
        self.load_btn.on_click(lambda _: self.load())
        self.panes = [W.HTML() for _ in range(4)]
        self.filter = W.Dropdown(options=[("All students", "all")], value="all", description="Show:")
        self.filter.observe(lambda _: self.draw_log(), names="value")
        self.log = W.HTML()
        self.ins_btn = W.Button(description="Ask Claude for cohort patterns", layout=W.Layout(width="260px", height="40px"))
        self.ins_btn.on_click(lambda _: self.run_insights())
        self.ins_out = W.HTML()
        self.tabs = W.Tab(children=[self.panes[0], self.panes[1], self.panes[2], W.VBox([self.filter, self.log]),
                                    W.VBox([self.panes[3], self.ins_btn, self.ins_out])])
        for i, t in enumerate(["Overview", "Exercise 1", "Exercise 2", "Exercise 3 log", "Cohort insights"]):
            self.tabs.set_title(i, t)
        self.root = W.VBox([W.HTML(CSS + TABLE_CSS), W.HTML('<h1 style="font-family:Georgia,serif;margin:4px 0">Teacher dashboard</h1>'),
                            W.HBox([self.load_btn, self.status], layout=W.Layout(align_items="center")), self.tabs])
        self.root.add_class("dva")

    def show(self):
        display(self.root)
        self.load()

    def load(self):
        try:
            results = client.all_results()
            self.calls = client.all_calls()
        except client.GatewayError as e:
            self.status.value = fb("bad", None, e.message)
            return
        self.S = latest_by_student(results)
        self.users = sorted(self.S, key=lambda u: -self.S[u]["last"])
        self.status.value = f'<span class="dva-hint">&nbsp; Loaded {len(results)} saved results from {len(self.S)} students at {time.strftime("%H:%M:%S")}.</span>'
        self.filter.options = [("All students", "all")] + [(u, u) for u in self.users]
        self.draw()

    def draw(self):
        spec, S = self.spec, self.S
        A = analyse(spec, S)
        self.A = A
        n = len(S)
        # overview
        if not n:
            self.panes[0].value = "<p>No student has started yet.</p>"
        else:
            c1 = sum(1 for s in S.values() if all(s["ex1"].get(p["id"], {}).get("stage") == "done" for p in spec["ex1"]))
            c2 = sum(1 for s in S.values() if all(s["ex2"].get(p["id"], {}).get("stage") == "done" for p in spec["ex2"]))
            c3 = sum(1 for s in S.values() if s["ex3"])
            rows = []
            for u in self.users:
                s = S[u]
                e1 = [p for p in spec["ex1"] if s["ex1"].get(p["id"], {}).get("s1") is not None]
                s1, t1 = sum(s["ex1"][p["id"]]["s1"] for p in e1), sum(len(p["sentences"]) for p in e1)
                e2 = [p for p in spec["ex2"] if s["ex2"].get(p["id"], {}).get("acc1") is not None]
                a2 = round(100 * sum(s["ex2"][p["id"]]["acc1"] for p in e2) / len(e2)) if e2 else None
                rows.append([esc(u), f"{s1} of {t1}" if t1 else "Not started", f"{a2}%" if a2 is not None else "Not started",
                             str(len(s["ex3"])), time.strftime("%d %b %H:%M", time.localtime(s["last"]))])
            self.panes[0].value = (f'<div class="dva-section"><p><b>{n}</b> students started · <b>{c1}</b> completed exercise 1 · '
                                   f'<b>{c2}</b> completed exercise 2 · <b>{c3}</b> got feedback in exercise 3</p>'
                                   + table(["Student", "Exercise 1: right first time", "Exercise 2: phrases right first time",
                                            "Exercise 3: feedback requests", "Last active"], rows, num=(3,)) + "</div>")
        # exercise 1
        items = []
        for it in A["ex1"]["items"]:
            w = max(it["wrong"].items(), key=lambda x: x[1])
            items.append([esc(short(it["s"]["text"], 12)), LABEL[it["s"]["key"]], f'{pct(it["right"], it["n"])}% of {it["n"]}' if it["n"] else "–",
                          f"{LABEL[w[0]]} ({w[1]} of {it['n']})" if w[1] else "–"])
        conf = A["ex1"]["confusion"]
        self.panes[1].value = ('<div class="dva-section"><p class="dva-hint">All figures use students’ first answers, before feedback.</p><h3>Each sentence</h3>'
                               + table(["Sentence", "Answer", "Right first time", "Most common wrong answer"], items)
                               + "<h3>What students chose, by correct answer</h3><p class='dva-hint'>Rows are the correct answer; columns are what students chose.</p>"
                               + table(["Correct answer", "Chose claim", "Chose reason", "Chose evidence"],
                                       [[LABEL[a]] + [str(conf[a][b]) for b in PARTS] for a in PARTS], num=(1, 2, 3))
                               + "<h3>Confidence and accuracy</h3>"
                               + table(["Confidence before checking", "Sentences answered", "Right first time"],
                                       [[l, str(A["ex1"]["conf"][k][1]), f'{pct(*A["ex1"]["conf"][k])}%' if A["ex1"]["conf"][k][1] else "–"] for k, l in CONF], num=(1, 2))
                               + "</div>")
        # exercise 2
        rows = [[esc(r["p"]["topic"]), str(r["n"]), f'{pct(r["all_right"], r["n"])}%' if r["n"] else "–"]
                + [f'{pct(*r["parts"][k])}%' if r["parts"][k][1] else "–" for k in PARTS]
                + [f'{pct(*r["nc"])}%' if r["nc"][1] else "–"] for r in A["ex2"]["paras"]]
        mis = sorted([(x["wrong"], r, x) for r in A["ex2"]["paras"] for x in r["chunks"].values() if x["wrong"]], key=lambda t: -t[0])
        mrows = [[f"“{esc(short(x['c']['text'], 10))}”", LABEL[x["c"]["key"]], f"{x['wrong']} of {r['n']}",
                  LABEL[max(x["as"].items(), key=lambda kv: kv[1])[0]]] for _, r, x in mis[:8]]
        self.panes[2].value = ('<div class="dva-section"><p class="dva-hint">All figures use students’ first attempts. A part counts as right when the student '
                               "marked exactly the phrases in the model answer.</p>"
                               + table(["Paragraph", "Students", "All right", "Claim right", "Reason right", "Evidence right", "“No claim” box right"], rows, num=(1, 2, 3, 4, 5, 6))
                               + "<h3>Phrases most often marked wrongly</h3>"
                               + (table(["Phrase", "Model answer", "Students who marked it wrongly", "Most common wrong marking"], mrows) if mrows else "<p>No data yet.</p>")
                               + "</div>")
        # insights
        bl = data_bullets(A)
        self.panes[3].value = ('<div class="dva-section"><h3>From the results</h3><p class="dva-hint">Calculated directly from students’ answers.</p>'
                               + ("<ul>" + "".join(f"<li>{esc(b)}</li>" for b in bl) + "</ul>" if bl else "<p>No data yet.</p>")
                               + "<h3>Claude’s reading of exercise 3</h3><p class='dva-hint'>Sends the statistics above and every exercise 3 submission "
                                 "to the gateway’s cohort-insights template, with students replaced by numbers.</p></div>")
        self.ins_btn.disabled = not A["ex3"]["subs"]
        self.draw_log()

    def draw_log(self):
        out = []
        for u in self.users if hasattr(self, "users") else []:
            if self.filter.value not in ("all", u):
                continue
            for i, x in enumerate(self.S[u]["ex3"]):
                r = x["result"]
                found = ", ".join(f"{LABEL[k]} {sum(1 for s in r['spans'] if s['part'] == k)}" for k in PARTS)
                miss = f". Missing: {', '.join(LOWER[m] for m in r['missing'])}." if r["missing"] else "."
                out.append((x["at"],
                    f'<div class="dva-card"><h3>{esc(u)}: version {i + 1}</h3><p class="dva-hint">{time.strftime("%d %b %H:%M", time.localtime(x["at"]))}'
                    f'{" · sample mode" if x.get("mode") == "sample" else ""}</p>'
                    f'<p><b>Stated claim:</b> {esc(x["stated"])}</p>{highlighted(x["text"], r["spans"])}'
                    f'<p><b>Overall:</b> {esc(TYPE[r["overall"]["type"]])}. {esc(r["overall"]["comment"])}</p>'
                    f'<p><b>Claim comparison:</b> {esc(MATCH[r["claim_match"]["level"]])} {esc(r["claim_match"]["comment"])}</p>'
                    f'<p><b>Found:</b> {found}{miss}</p><p><b>Pointers given:</b></p><ul>'
                    + "".join(f"<li>{esc(p)}</li>" for p in r["pointers"]) + "</ul></div>"))
        out.sort(key=lambda t: -t[0])
        self.log.value = "".join(h for _, h in out) or "<p>No submissions yet.</p>"

    def run_insights(self):
        self.ins_btn.disabled = True
        self.ins_out.value = '<p class="dva-hint">Asking Claude through the gateway…</p>'
        idx = {u: i + 1 for i, u in enumerate(self.users)}
        recs = [{"student": idx[u], "version": i + 1, "paragraph": x["text"][:1500], "stated_claim": x["stated"][:300],
                 "found": [{"part": s["part"], "quote": s["quote"][:200]} for s in x["result"]["spans"]],
                 "missing": x["result"]["missing"], "claim_match": x["result"]["claim_match"]["level"], "overall": x["result"]["overall"]["type"]}
                for u, x, i in self.A["ex3"]["subs"]][:120]
        try:
            r = client.run_template("cohort-insights", {"STATS": "\n".join(data_bullets(self.A)), "RECORDS": json.dumps(recs)}, teacher=True)
            o = r["output"]
            pats = "".join(f'<div class="dva-card"><h4>{esc(p.get("title", ""))}</h4><p>{esc(p.get("detail", ""))}</p>'
                           f'<p class="dva-hint">{esc(p.get("students_affected", ""))}</p>'
                           + (f'<p style="font-family:Georgia,serif;border-left:4px solid #6B7689;padding-left:8px">{esc(p["example"])}</p>' if p.get("example") else "")
                           + "</div>" for p in o.get("patterns", [])[:6])
            sug = "".join(f"<li>{esc(s)}</li>" for s in o.get("suggestions", [])[:4])
            note = "<p class='dva-notice'><b>Sample mode.</b> The gateway has no API key, so this is example output.</p>" if r["mode"] == "sample" else ""
            self.ins_out.value = (f"<h3>Claude’s summary, {time.strftime('%d %b %H:%M')} ({len(recs)} submissions)</h3>{note}{pats}"
                                  + (f"<h4>Suggestions for teaching</h4><ul>{sug}</ul>" if sug else ""))
        except client.GatewayError as e:
            self.ins_out.value = fb("bad", None, e.message)
        self.ins_btn.disabled = False

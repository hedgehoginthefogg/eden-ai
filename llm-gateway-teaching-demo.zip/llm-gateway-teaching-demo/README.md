# Constrained LLM use through a gateway: a teaching demo

This repository is a working demonstration of how students could use a large language model (LLM) in a course without a chatbot interface. The LLM is available only at a fixed point in an activity, with a fixed prompt written by the teacher, and every request is limited and logged.

It was built by Steven Williams, AI and Education Specialist at LSE, to support conversations with LSE's Digital Technology Services (DTS) about educators' requirements. The content was drafted quickly and hasn't been checked, so treat it as a technical demo rather than teaching material.

The example activity, "Descriptive or analytical?", teaches MSc students on a global health policy course to recognise claims, reasons and evidence in their writing. It has three exercises:

1. **Sort sentences.** Students mark each sentence in three short paragraphs as a claim, a reason or evidence. Answers are marked against fixed answers, with fixed feedback for each wrong choice.
2. **Highlight paragraphs.** Students mark the claim, reasons and evidence in four example paragraphs, one of which has no claim. These are also marked against fixed answers.
3. **Your paragraph.** Students paste a paragraph of their own and state its claim. The LLM highlights the claim, reasons and evidence it finds and gives pointers, without rewriting the paragraph. This is the only exercise that uses the LLM.

A teacher dashboard collects every student's results and exercise 3 submissions, calculates where the cohort struggles, and can ask the LLM to summarise patterns across the anonymised submissions.

The same activity also exists as a claude.ai artifact. Both versions load the same activity file, `activity/activity_spec.json`, so they use the same content, marking rules, prompts and record format.

## Why the gateway holds the prompts

In a notebook, students can see and edit the code. If the notebook held an API key, a student could change the code and use the key for anything, turning it into a free, unlogged chatbot. That stays true even if the key is routed through a logging proxy.

So in this design the gateway holds the prompts as well as the key. The notebook can only say "run the `paragraph-feedback` template with this paragraph and this claim". The gateway fills in the prompt, checks the inputs, calls the model, checks the reply, logs everything, and enforces the student's request limit. A student who edits the notebook can still only get paragraph feedback, three times.

The same gateway could serve very different courses. A programming course could register a template that explains an error message in a student's code. A writing course could register one like this. Each course gets its own templates, limits and logs, and none of them gets a chatbot.

## How the parts fit together

```
 Student notebook ──┐                      ┌── holds the API key
 (ipywidgets)       │   web requests       │── holds the registered prompt templates
                    ├────────────────────► │   checks inputs and replies
 Teacher notebook ──┘   template name      │   enforces limits per student
 (ipywidgets)           + variables only   │   logs every request, reply and refusal
                                           │   stores exercise results
                            GATEWAY ───────┘
                               │
                               ▼
                        Anthropic API (Claude)
```

In this demo all three run on one machine, the Codespace. In a real deployment, the gateway would run on a university server, and students would reach the notebooks through a managed service such as JupyterHub, signed in with their university account. The only change in the notebooks would be the gateway's address.

## What's in this repository

| Path | What it is |
| --- | --- |
| `0_start_gateway.ipynb` | Starts the gateway as a background service. Run this first. |
| `1_student_activity.ipynb` | The student activity. |
| `2_teacher_dashboard.ipynb` | The teacher dashboard. |
| `3_gateway_console.ipynb` | For technical colleagues: shows what the gateway refuses and what it logs. Its code is visible on purpose. |
| `gateway/app.py` | The reference gateway, a small FastAPI web service. |
| `lib/` | The notebooks' code: the interfaces, marking rules and gateway client. |
| `activity/activity_spec.json` | The activity's content, answer keys, fixed feedback and prompts. |
| `tests/` | Automated tests of the gateway's limits and the marking rules. |
| `.devcontainer/devcontainer.json` | Tells GitHub Codespaces what to install. |

## Running it in GitHub Codespaces

GitHub Codespaces runs a complete development set-up in your browser, so you don't need to install anything. Personal GitHub accounts get a monthly free allowance of Codespaces time. Stop your codespace when you've finished, so it doesn't use the allowance while idle.

The data you enter is stored in the codespace, on GitHub's servers. Use test data only.

1. **Create a repository.** On github.com, choose **New repository**. Give it a name such as `llm-gateway-teaching-demo`, set it to **Private**, and create it.
2. **Upload the files.** On the new repository's page, choose **uploading an existing file**, then drag in everything from this folder and commit. Check that the `.devcontainer` folder was uploaded: on a Mac, Finder hides folders whose names start with a dot, and **Cmd+Shift+.** shows them. Without that folder, the codespace won't install what the notebooks need.
3. **Optionally, add an API key** (see the next section). Without one, the gateway runs in sample mode.
4. **Open a codespace.** On the repository's page, choose **Code**, then the **Codespaces** tab, then **Create codespace on main**. The first start takes a few minutes while it installs the packages.
5. **Start the gateway.** Open `0_start_gateway.ipynb`. If you're asked to choose a kernel, choose **Python Environments**, then the Python 3.12 environment. Click the code cell and press **Shift+Enter**. It should report that the gateway has started.
6. **Try the activity.** Open `1_student_activity.ipynb` and run its cell. Sign in with any name, for example a different name for each test student.
7. **See the results.** Open `2_teacher_dashboard.ipynb` and run its cell.
8. **Show the gateway's constraints.** Open `3_gateway_console.ipynb` and run its cells in order.

Each time you reopen the codespace, run `0_start_gateway.ipynb` again before the other notebooks.

### The app view, with no code

Voilà shows a notebook as a web page, with the code hidden. To use it, open a terminal (**Terminal**, then **New Terminal**) and run:

```
voila 1_student_activity.ipynb --port 8866 --no-browser
```

Then open the **Ports** tab and open port 8866 in the browser. For the teacher dashboard, run the same command in a second terminal with `2_teacher_dashboard.ipynb` and port 8867.

## Using real Claude feedback

Without an API key, the gateway runs in **sample mode**. It returns example feedback made by simple rules, clearly labelled as sample feedback, so the whole flow works without any cost.

For real feedback, the gateway needs an Anthropic API key. API keys come from the Anthropic Console (https://console.anthropic.com) and are billed separately from claude.ai subscriptions, including LSE's Claude licence. Testing this demo with a handful of requests costs very little, but check the current pricing on Anthropic's website.

To add the key:

1. In your GitHub repository, go to **Settings**, then **Secrets and variables**, then **Codespaces**.
2. Choose **New repository secret**. Name it `ANTHROPIC_API_KEY` and paste the key as its value.
3. If a codespace is already open, rebuild it so it picks up the secret: open the Command Palette (**Ctrl+Shift+P**, or **Cmd+Shift+P** on a Mac) and run **Codespaces: Rebuild Container**.
4. Run `0_start_gateway.ipynb`. It should now report live mode.

The key is visible only to the gateway, through the codespace's environment. The notebooks never read it.

The model is set by the `GATEWAY_MODEL` environment variable, which defaults to `claude-sonnet-5-5`. See Anthropic's documentation (https://docs.claude.com/en/api/overview) for current model names.

## What the demo shows a gateway needs to do

These are the requirements the reference gateway implements, written as a starting point for discussion with DTS.

1. **Hold API keys centrally.** Students and teachers never handle keys.
2. **Run only registered templates.** A client sends a template name and its variables, never a prompt. Teachers register templates for their course.
3. **Check every input.** Each template declares exactly which variables it accepts and their length limits. Anything else is refused.
4. **Check every reply.** Replies that aren't in the template's expected format are logged and returned as an error, and don't count against the student's limit.
5. **Limit use per student.** Each template has a request limit per student. A production gateway would also need budgets per course.
6. **Take identity from university sign-in.** In this demo, students type a name. A real gateway must take identity from single sign-on, never from a value the client chooses.
7. **Separate student and teacher templates.** The cohort-insights template accepts only teacher credentials.
8. **Log everything.** For each request, the gateway logs who sent it, when, which template, the variables, the full prompt sent to the model, the reply, the token counts and the time taken. It also logs refused requests and the reason for each.
9. **Store results for teachers.** Students' exercise results go to the gateway, and teachers fetch their course's results from it.

A production service would also need decisions on a data protection impact assessment, data retention, who can read logs, the notice given to students, cost reporting, and which models and providers are approved. Existing gateway products may cover several of these requirements, such as central keys, logging and budgets. Examples worth evaluating include the LiteLLM proxy, Azure API Management's AI gateway features and Cloudflare AI Gateway. Check whether each can restrict clients to registered templates, or whether that needs a thin layer in front of it, like the one in this demo.

## What's simplified in this demo

- **Identity.** Students sign in by typing a name, so anyone can claim any name.
- **Teacher access.** The teacher token is a fixed demo value, `demo-teacher-token`, set by the `TEACHER_TOKEN` environment variable.
- **Storage.** Everything is stored in one SQLite file, `gateway/gateway.db`, on the codespace. Deleting that file resets the demo.
- **Templates.** Templates are defined in code in `gateway/app.py`, rather than managed by teachers through an interface.
- **Accessibility.** The ipywidgets interface can be used with a keyboard, and every coloured choice also has a text label. Screen-reader support for notebook widgets is limited, so a production interface would need testing with assistive technology.

## Running the tests

In a terminal in the codespace, run:

```
python -m pytest -q
```

The tests check that the gateway refuses unknown templates, extra variables, over-long inputs, teacher templates without the token, and requests over the limit. They also check that it logs requests and refusals, and that the model answers in the activity file score full marks.

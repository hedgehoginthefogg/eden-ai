"""Reference LLM gateway for constrained, logged LLM use in teaching.

This is a demonstration, not production code. It shows what a gateway needs
to do so that students can use an LLM only in the ways a course allows:

* It holds the API key. Notebooks never see it.
* It holds the prompts. A notebook can only ask for a registered template by
  name and fill in its variables, so the key can't be reused as a general
  chatbot, even though students can see and edit the notebook's code.
* It checks every input against the template's limits, and every reply
  against the template's expected format.
* It enforces per-student request limits.
* It logs every request and reply against the student's ID, and logs every
  refused request.
* It stores exercise results so a teacher notebook can collect them.

Identity: in this demo, students type a name, which the notebook sends in an
X-Demo-User header. A real gateway would take the student's identity from
institutional sign-in (for example single sign-on through JupyterHub), never
from a value the client chooses.
"""
import json
import os
import re
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from typing import Any

import requests
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

ROOT = Path(__file__).resolve().parent.parent
SPEC = json.loads((ROOT / "activity" / "activity_spec.json").read_text(encoding="utf-8"))
DB_PATH = Path(os.environ.get("GATEWAY_DB", ROOT / "gateway" / "gateway.db"))
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "").strip()
MODEL = os.environ.get("GATEWAY_MODEL", "claude-sonnet-5-5")
TEACHER_TOKEN = os.environ.get("TEACHER_TOKEN", "demo-teacher-token")
MODE = "live" if API_KEY else "sample"

# --------------------------------------------------------------------------
# Templates: the only things the gateway will ask the model to do. Each one
# names its variables, the limits on them, who may use it and how often.
# --------------------------------------------------------------------------
TEMPLATES: dict[str, dict[str, Any]] = {
    "paragraph-feedback": {
        "description": "Exercise 3: feedback on the structure of one paragraph of a student's own writing.",
        "audience": "student",
        "prompt": SPEC["ex3"]["prompt"],
        "variables": {
            "PARAGRAPH": {"min_words": SPEC["ex3"]["minWords"], "max_words": SPEC["ex3"]["maxWords"], "max_chars": 2500},
            "STATED_CLAIM": {"min_words": 3, "max_words": 60, "max_chars": 400},
        },
        "max_requests_per_user": SPEC["ex3"]["maxRequests"],
        "max_tokens": 1500,
        "required_keys": ["spans", "missing", "claim_match", "pointers", "overall"],
    },
    "cohort-insights": {
        "description": "Teacher view: patterns across the cohort's exercise 3 submissions.",
        "audience": "teacher",
        "prompt": SPEC["insightsPrompt"],
        "variables": {"STATS": {"max_chars": 8000}, "RECORDS": {"max_chars": 200000}},
        "max_requests_per_user": 20,
        "max_tokens": 2500,
        "required_keys": ["patterns", "suggestions"],
    },
}

# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------
_lock = threading.Lock()


def db() -> sqlite3.Connection:
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    con.row_factory = sqlite3.Row
    return con


def init_db() -> None:
    with _lock, db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS llm_calls (
          id TEXT PRIMARY KEY, at REAL, user TEXT, template TEXT, variables TEXT,
          prompt TEXT, model TEXT, mode TEXT, raw_reply TEXT, output TEXT,
          ok INTEGER, error TEXT, input_tokens INTEGER, output_tokens INTEGER, ms INTEGER);
        CREATE TABLE IF NOT EXISTS results (
          id TEXT PRIMARY KEY, at REAL, user TEXT, exercise TEXT, item TEXT, record TEXT);
        CREATE TABLE IF NOT EXISTS refusals (
          id TEXT PRIMARY KEY, at REAL, user TEXT, template TEXT, reason TEXT);
        """)


init_db()


def used(user: str, template: str) -> int:
    with db() as con:
        return con.execute("SELECT COUNT(*) FROM llm_calls WHERE user=? AND template=? AND ok=1",
                           (user, template)).fetchone()[0]


def refuse(status: int, user: str, template: str, reason: str):
    with _lock, db() as con:
        con.execute("INSERT INTO refusals VALUES (?,?,?,?,?)",
                    (uuid.uuid4().hex, time.time(), user, template, reason))
    raise HTTPException(status, reason)


# --------------------------------------------------------------------------
# Model call
# --------------------------------------------------------------------------
def call_model(prompt: str, max_tokens: int) -> tuple[str, int, int]:
    r = requests.post(
        "https://api.anthropic.com/v1/messages", timeout=90,
        headers={"x-api-key": API_KEY, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": MODEL, "max_tokens": max_tokens, "messages": [{"role": "user", "content": prompt}]})
    if r.status_code != 200:
        raise RuntimeError(f"Model API returned {r.status_code}: {r.text[:300]}")
    body = r.json()
    text = "".join(b.get("text", "") for b in body.get("content", []) if b.get("type") == "text")
    u = body.get("usage", {})
    return text, u.get("input_tokens", 0), u.get("output_tokens", 0)


def parse_json(text: str) -> Any:
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip())
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, re.S)
        if m:
            return json.loads(m.group(0))
        raise


def sample_reply(template: str, variables: dict[str, str]) -> str:
    """Example output for sample mode (no API key), made by simple rules."""
    if template == "paragraph-feedback":
        para = variables["PARAGRAPH"]
        sents = [s.strip() for s in re.findall(r"[^.!?]+[.!?]", para)] or [para.strip()]
        spans, seen = [{"part": "claim", "quote": sents[0]}], set()
        for s in sents[1:]:
            low = s.lower()
            if re.search(r"\d", s) and "evidence" not in seen:
                spans.append({"part": "evidence", "quote": s})
                seen.add("evidence")
            elif re.search(r"\b(because|therefore|so that|this means|which means)\b", low) and "reason" not in seen:
                spans.append({"part": "reason", "quote": s})
                seen.add("reason")
        missing = [p for p in ("reason", "evidence") if p not in seen]
        return json.dumps({
            "spans": spans, "missing": missing,
            "claim_match": {"level": "partly", "comment": "Sample mode: this comparison is an example, not a reading of your claim."},
            "pointers": ["Sample mode: which sentence explains why your evidence supports your first sentence?",
                         "Sample mode: is every fact in your paragraph doing work for your claim?"],
            "overall": {"type": "mixed" if len(spans) > 1 else "descriptive",
                        "comment": "Sample mode: the gateway has no API key, so this feedback is an example made by simple rules."}})
    return json.dumps({
        "patterns": [{"title": "Sample mode", "detail": "The gateway has no API key, so this is example output rather than a reading of the cohort.",
                      "students_affected": "", "example": ""}],
        "suggestions": ["Add an API key to the gateway to see real patterns."]})


# --------------------------------------------------------------------------
# API
# --------------------------------------------------------------------------
app = FastAPI(title="Teaching LLM gateway (reference demo)")


class RunBody(BaseModel):
    variables: dict[str, str]


class ResultBody(BaseModel):
    exercise: str
    item: str
    record: dict[str, Any]


def identify(x_demo_user: str | None, x_teacher_token: str | None, audience: str) -> str:
    if audience == "teacher":
        if x_teacher_token != TEACHER_TOKEN:
            raise HTTPException(403, "This template is for teachers only.")
        return "teacher"
    if not x_demo_user or not x_demo_user.strip():
        raise HTTPException(401, "No user identity was sent.")
    return x_demo_user.strip()[:80]


@app.get("/health")
def health():
    return {"ok": True, "mode": MODE, "model": MODEL if MODE == "live" else None}


@app.get("/v1/templates")
def list_templates():
    return [{"id": k, "description": v["description"], "audience": v["audience"],
             "max_requests_per_user": v["max_requests_per_user"], "variables": v["variables"]}
            for k, v in TEMPLATES.items()]


@app.get("/v1/usage/{template_id}")
def usage(template_id: str, x_demo_user: str | None = Header(None)):
    t = TEMPLATES.get(template_id)
    if not t:
        raise HTTPException(404, "No such template.")
    user = identify(x_demo_user, None, "student")
    n = used(user, template_id)
    return {"used": n, "limit": t["max_requests_per_user"], "remaining": max(0, t["max_requests_per_user"] - n)}


@app.post("/v1/run/{template_id}")
def run(template_id: str, body: RunBody,
        x_demo_user: str | None = Header(None), x_teacher_token: str | None = Header(None)):
    t = TEMPLATES.get(template_id)
    if not t:
        refuse(404, x_demo_user or "?", template_id, "No such template. The gateway only runs registered templates.")
    user = identify(x_demo_user, x_teacher_token, t["audience"])
    if set(body.variables) != set(t["variables"]):
        refuse(422, user, template_id, f"Expected exactly these variables: {sorted(t['variables'])}.")
    for name, rule in t["variables"].items():
        v = body.variables[name]
        words = len(v.split())
        if len(v) > rule.get("max_chars", 10**9):
            refuse(422, user, template_id, f"{name} is longer than {rule['max_chars']} characters.")
        if words < rule.get("min_words", 0):
            refuse(422, user, template_id, f"{name} needs at least {rule['min_words']} words.")
        if words > rule.get("max_words", 10**9):
            refuse(422, user, template_id, f"{name} has more than {rule['max_words']} words.")
    if used(user, template_id) >= t["max_requests_per_user"]:
        refuse(429, user, template_id, f"Request limit reached ({t['max_requests_per_user']} for this template).")

    prompt = t["prompt"]
    for name, v in body.variables.items():
        prompt = prompt.replace("{{" + name + "}}", v.strip())
    t0, call_id = time.time(), uuid.uuid4().hex
    raw, tin, tout, output, err = "", 0, 0, None, None
    try:
        if MODE == "live":
            raw, tin, tout = call_model(prompt, t["max_tokens"])
        else:
            raw = sample_reply(template_id, body.variables)
        output = parse_json(raw)
        missing = [k for k in t["required_keys"] if k not in output]
        if missing:
            raise ValueError(f"Reply is missing keys: {missing}")
    except Exception as e:  # logged, and not counted against the user's limit
        err = str(e)[:500]
    with _lock, db() as con:
        con.execute("INSERT INTO llm_calls VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (call_id, t0, user, template_id, json.dumps(body.variables), prompt, MODEL, MODE, raw,
                     None if err else json.dumps(output), 0 if err else 1, err, tin, tout,
                     int(1000 * (time.time() - t0))))
    if err:
        raise HTTPException(502, "The model's reply couldn't be used. This request wasn't counted against your limit.")
    return {"call_id": call_id, "output": output, "mode": MODE,
            "remaining": max(0, t["max_requests_per_user"] - used(user, template_id))}


@app.post("/v1/results")
def save_result(body: ResultBody, x_demo_user: str | None = Header(None)):
    user = identify(x_demo_user, None, "student")
    if body.exercise not in ("ex1", "ex2", "ex3"):
        raise HTTPException(422, "Unknown exercise.")
    rec = json.dumps(body.record)
    if len(rec) > 100_000:
        raise HTTPException(413, "Record too large.")
    with _lock, db() as con:
        con.execute("INSERT INTO results VALUES (?,?,?,?,?,?)",
                    (uuid.uuid4().hex, time.time(), user, body.exercise, body.item, rec))
    return {"ok": True}


@app.get("/v1/my-results")
def my_results(x_demo_user: str | None = Header(None)):
    user = identify(x_demo_user, None, "student")
    with db() as con:
        rows = con.execute("SELECT at, exercise, item, record FROM results WHERE user=? ORDER BY at", (user,)).fetchall()
    return [{"at": r["at"], "exercise": r["exercise"], "item": r["item"], "record": json.loads(r["record"])} for r in rows]


def teacher_only(token: str | None):
    if token != TEACHER_TOKEN:
        raise HTTPException(403, "Teacher token required.")


@app.get("/admin/results")
def all_results(x_teacher_token: str | None = Header(None)):
    teacher_only(x_teacher_token)
    with db() as con:
        rows = con.execute("SELECT at, user, exercise, item, record FROM results ORDER BY at").fetchall()
    return [{"at": r["at"], "user": r["user"], "exercise": r["exercise"], "item": r["item"],
             "record": json.loads(r["record"])} for r in rows]


@app.get("/admin/calls")
def all_calls(x_teacher_token: str | None = Header(None), limit: int = 500):
    teacher_only(x_teacher_token)
    with db() as con:
        rows = con.execute("SELECT * FROM llm_calls ORDER BY at DESC LIMIT ?", (limit,)).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        d["variables"] = json.loads(d["variables"])
        d["output"] = json.loads(d["output"]) if d["output"] else None
        out.append(d)
    return out


@app.get("/admin/refusals")
def all_refusals(x_teacher_token: str | None = Header(None)):
    teacher_only(x_teacher_token)
    with db() as con:
        return [dict(r) for r in con.execute("SELECT * FROM refusals ORDER BY at DESC LIMIT 200").fetchall()]
